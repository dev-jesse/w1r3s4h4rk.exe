username = input("Enter the username here: ")
password = input("Enter the password here: ")

print(hash(username + password))
